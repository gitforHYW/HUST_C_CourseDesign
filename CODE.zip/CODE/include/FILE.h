#ifndef _FILE_H_
#define _FILE_H_

int save(Hnode* Hp) ;
int saveas(Hnode* Hp);
int FreeAll(Hnode* p);
int Freenode(node* p) ;
Hnode* opens(Hnode* Hp,Hnode **Chead);
int newbuild(Hnode* Hp,Hnode **Chead);
#endif
