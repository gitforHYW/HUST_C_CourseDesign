#ifndef _SEEKBAR_H_
#define _SEEKBAR_H_

void drawskbar(Hnode* Hhead);
int up_page(Hnode* Hp,Hnode **Chead);
int down_page(Hnode* Hp,Hnode **Chead);
int newskbar(Hnode* Hhead,int r);
int click_skbar(Hnode* Hhead,Hnode **Chead);
#endif
