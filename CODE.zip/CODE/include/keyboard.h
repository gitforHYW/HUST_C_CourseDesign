#ifndef KEYBOARD_H
#define KEYBOARD_H
#ifndef __BORLANDC__
#pragma warning(disable:4996)
#endif
int get_c(void);
#endif
