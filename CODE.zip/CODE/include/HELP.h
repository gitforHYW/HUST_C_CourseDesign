#ifndef _HELP_H_
#define _HELP_H_

void help();
void about();
#endif
